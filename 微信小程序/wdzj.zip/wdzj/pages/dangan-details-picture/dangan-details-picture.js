// pages/dangan-details-picture/dangan-details-picture.js
var urlList = [];
var platId = '';
var app = getApp();
Page({
  data:{
    contractList:[],
    certificateInfo:[],
    officeEnvironmentInfo:[],
    hidden:false
  },
  onLoad:function(options){
    var that = this;
    platId = options.platId;
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IarchiveSpotPicture', //仅为示例，并非真实的接口地址
      data: {
        platId:options.platId
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        var json = res.data.data;
        if(json.contractList.length>0){
          for(let i=0;i<json.contractList.length;i++){
            urlList.push(json.contractList[i].contractImg);
          }
        }
        if(json.certificateInfo.length>0){
          for(let i=0;i<json.certificateInfo.length;i++){
            urlList.push(json.certificateInfo[i].certificateInfoImg);
          }
        }
        if(json.officeEnvironmentInfo.length>0){
          for(let i=0;i<json.officeEnvironmentInfo.length;i++){
            urlList.push(json.officeEnvironmentInfo[i].officeEnvironmentImg);
          }
        }
        that.setData({
          contractList:json.contractList,
          certificateInfo:json.certificateInfo,
          officeEnvironmentInfo:json.officeEnvironmentInfo,
          hidden:true
        });
      },
      fail: function() {
          app.failShow()
      }
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  pictrueShow:function(res){
    var this_pic = res.target.dataset.src;
    wx.previewImage({
      current: this_pic, // 当前显示图片的http链接
      urls: urlList // 需要预览的图片http链接列表
    })
  },
  onShareAppMessage: function () {
        return {
        title: '现场实拍',
        desc: '',
        path: '/pages/dangan-details-picture/dangan-details-picture?platId='+platId
        }
    }
})