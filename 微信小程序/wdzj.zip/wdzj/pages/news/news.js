// pages/news/news.js
var app = getApp();
Page({
  data:{
	  picture : [],
    indicatorDots: false,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    circular:true,
    loading : false,
    pageNum :2,
    nodata: true,
    height : 'auto',
    hidden:true,
    list:[],
    listType:[]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this;
    var headUrl = 'https://phpservice.wdzj.com/wxchat/index/InewsList';

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          height : res.windowHeight + "px"
        });
      }
    });

    //幻灯初始化
    that.loadData(headUrl,{},function(res){
      var listTab = [];
      var listType = [];
      var json = res.data;

      if(json.error_code == 0){
        for(var i=0; i<json.data.news.list.length; i++){
            for(var j=0; j<json.data.news.list[i].newsList.length; j++){
              listTab.push(json.data.news.list[i].newsList[j]);
              if(json.data.news.list[i].newsList[j].subjectType == 1){
                listType.push(json.data.news.list[i].newsList[j].subjectType);
              }
            }
        }
        if(listType.length<=4){
          that.refesh();
        }
        that.setData({
          picture : json.data.pictures,
          loading : true,
          list : listTab,
          listType:listType,
          hidden:false
        });
      }
      
    });

  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onReachBottom:function(){
    var that = this;
    that.refesh();
  },

  refesh : function(){
    var that = this;

    that.setData({
      loading : false,
    });

    that.listData(that.data.pageNum,function(res){
      var json = res.data;
      var listArr = [];
      if(json.error_code == 0){
        if(json.data.length > 0){

          for(var i=0; i<json.data.length; i++ ){
            for(var j=0; j<json.data[i].newsList.length; j++){
              listArr.push(json.data[i].newsList[j]);
            }
          }
          that.setData({
            pageNum : that.data.pageNum + 1,
            loading : true,
            list : that.data.list.concat(listArr)
          });

        } else {
          that.setData({
            loading : true,
            nodata : false
          });

          setTimeout(function(){
            that.setData({
              nodata : true
            });
          },2000);
        }
      }
    });
  },

  loadData : function(url,data,callback){
    wx.request({
      url: url,
      data: data,
      method: 'GET',
      header: {
         'content-type': 'application/json'
      },
      success: function(res){
        callback(res);
      },
      fail:function(){
        app.failShow()
      }
    })
  },

  listData : function(pageNum,callback){
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/InewsListMore',
      data: {
        page : pageNum
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function(res){
        callback(res);
      },
      fail: function() {
          app.failShow()
      }
    })
  },
  onShareAppMessage: function () {
    var that = this;
        return {
        title: '网贷新闻_提供P2P理财行业相关资讯',
        desc: '网贷之家新闻频道是P2P理财的新闻中心,包含有网贷政策、网贷行业等资讯内容',
        path: '/pages/news/news'
        }
    }
})