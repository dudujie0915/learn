//siftlist.js
var paramsObj = {};
var datas = {
    "page": "1",
    "pagesize": "1",
    "filedall": "0",
    "params": ""
};
var params = {
    "feature": {
        "key": "feature",
        "title": "", //平台特征
        "list": [{
            "key": "6",
            "val": "发展评级 100 强"
        }, {
            "key": "8",
            "val": "资金银行存管"
        }, {
            "key": "7",
            "val": "获ICP许可证"
        }, {
            "key": "1",
            "val": "风投注资"
        }, {
            "key": "2",
            "val": "加入监管协会"
        }, {
            "key": "4",
            "val": "网贷之家考察"
        }]
    },
    "platStatus": {
        "key": "platStatus",
        "title": "运营状态",
        "list": [{
            "key": "1",
            "val": "运营中"
        }, {
            "key": "2,8",
            "val": "停业或转型"
        }, {
            "key": "3,5,6,7",
            "val": "问题平台"
        }]
    },
    "rate": {
        "key": "rate",
        "title": "平均利率",
        "list": [{
            "key": "1",
            "val": "≤8%"
        }, {
            "key": "2",
            "val": "8%～12%"
        }, {
            "key": "3",
            "val": "12%～16%"
        }, {
            "key": "4",
            "val": "16%～20%"
        }, {
            "key": "5",
            "val": "≥20%"
        }]
    },
    "term": {
        "key": "term",
        "title": "投资期限",
        "list": [{
            "key": "1",
            "val": "天标"
        }, {
            "key": "2",
            "val": "1月标"
        }, {
            "key": "3",
            "val": "2月标"
        }, {
            "key": "4",
            "val": "3月标"
        }, {
            "key": "5",
            "val": "4-6月标"
        }, {
            "key": "6",
            "val": "6-12月标"
        }, {
            "key": "7",
            "val": "12月以上标"
        }]
    },
    "city": {
        "key": "city",
        "title": "注册地",
        "list": []
    },
    "capital": {
        "key": "capital",
        "title": "注册资金",
        "list": [{
            "key": "1",
            "val": "小于500万"
        }, {
            "key": "2",
            "val": "500～999万"
        }, {
            "key": "3",
            "val": "1000～3000万"
        }, {
            "key": "4",
            "val": "3000-9999万"
        }, {
            "key": "5",
            "val": "一亿以上"
        }]
    },
    "online": {
        "key": "online",
        "title": "上线时间",
        "list": []
    },
    "security": {
        "key": "security",
        "title": "保障模式",
        "list": [{
            "key": "02",
            "val": "风险准备金"
        }, {
            "key": "1",
            "val": "小贷公司"
        }, {
            "key": "2",
            "val": "融资性担保公司"
        }, {
            "key": "3",
            "val": "非融资性担保公司"
        }, {
            "key": "4",
            "val": "平台垫付"
        }, {
            "key": "01",
            "val": "其他"
        }]
    },
    "trustfunds": {
        "key": "trustfunds",
        "title": "风险准备金存管",
        "list": [{
            "key": "1,3",
            "val": "风险准备金银行存管"
        }, {
            "key": "2,4",
            "val": "风险准备金第三方存管"
        }, {
            "key": "null",
            "val": "无存管"
        }]
    },
    "creditor": {
        "key": "creditor",
        "title": "债权转让",
        "list": [{
            "key": "1",
            "val": "随时转让"
        }, {
            "key": "2",
            "val": "1个月后可转让"
        }, {
            "key": "3",
            "val": "3个月后可转让"
        }, {
            "key": "4",
            "val": "1年后可转让"
        }, {
            "key": "5",
            "val": "不可转让"
        }]
    },
    "autobid": {
        "key": "autobid",
        "title": "自动投标",
        "list": [{
            "key": "true",
            "val": "支持"
        }, {
            "key": "false",
            "val": "不支持"
        }]
    },
    "platBackground": {
        "key": "platBackground",
        "title": "平台背景",
        "list": [{
            "key": "1",
            "val": "银行系"
        }, {
            "key": "2",
            "val": "民营系"
        }, {
            "key": "3",
            "val": "上市公司系"
        }, {
            "key": "4",
            "val": "国资系"
        }]
    },
    "businessTypeOr": {
        "key": "businessTypeOr",
        "title": "业务类型",
        "list": []
    }
};
// 处理数据格式
var datags = function(arr, keyname, valname) {
        var arrs = [];
        for (var i = 0; i < arr.length; i++) {
            arrs[i] = {};
            arrs[i].key = arr[i][keyname];
            arrs[i].val = arr[i][valname];
        }
        return arrs;
    }
    // 设置属性
var setclass = function() {
    paramsObj["platStatus"] = "1,";
    getpt();
    for (var i in params) {
        for (var j in params[i].list) {
            if (params[i].key == "platStatus" && params[i].list[j].key == "1") {
                params[i].list[j].open = true;
            } else {
                params[i].list[j].open = false;
            }
        }
    }
};
// 参数拼接
var getpt = function(val) {
	if(val){
	    if (val.cur) {
	        paramsObj[val.key] ? '' : paramsObj[val.key] = '';
	        paramsObj[val.key] += val.val + ',';
	        paramsObj[val.key] = paramsObj[val.key].replace(/,/g, '＃');
	    } else {
	        paramsObj[val.key] = paramsObj[val.key].replace(/＃/g, ',');
	        paramsObj[val.key] = paramsObj[val.key].replace(val.val + ',', '');
	        paramsObj[val.key] = paramsObj[val.key].replace(/,/g, '＃');
	    }
	}
    datas.params = "";
    for (var i in paramsObj) {
        if(paramsObj[i]){
            datas.params += i + ":" + paramsObj[i].substring(0, paramsObj[i].length - 1) + ",";
        }
    }
};
Page({
    data: {
        listdata: {},
        num: 0
    },
    onLoad: function() {
        var that = this;
        // 获取数据
        wx.request({
            url: 'https://phpservice.wdzj.com/wxchat/index/IselectProvenceDate',
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                if(res.data.error_code == 0){
                    params["city"]["list"] = datags(res.data.data.province, 'cityId', 'city');
                    params["online"]["list"] = res.data.data.date;
                    params["businessTypeOr"]["list"] = datags(res.data.data.bustype, 'value', 'name');
                    // 设置属性
                    setclass();
                    // 更新数据
                    that.setData({
                        listdata: params
                    });
                    that.getsx();
                }else{
                    that.getsx();
                    wx.showModal({
                        content: res.data.msg,
                        showCancel: false
                    })
                }
            },
            fail: function() {
                app.failShow()
            }
        });
    },
    reset: function() {
        // 设置属性
        setclass();
        // 更新数据
        this.setData({
            listdata: params
        });
        this.getsx();
    },
    getsx: function() {
        var that = this;
        var urlcs = datas.params;
        urlcs = urlcs.replace(/:/g, '=').replace(/,/g, '&');
        // 筛选平台
        wx.request({
            url: 'https://phpservice.wdzj.com/wxchat/index/IplatSelect',
            data: datas,
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
            method: "POST",
            success: function(res) {
                if(res.data.error_code == -1){
                    wx.showModal({
                        content: res.data.msg,
                        showCancel: false
                    })
                }else{
                    that.setData({
                    	datas: urlcs,
                        num: res.data.mapinfo.size
                    });
                }
                // 关闭标题栏加载动画
                wx.hideNavigationBarLoading();
            },
            fail: function() {
                app.failShow()
            }
        })
    },
    getnum: function(event) {
        var that = this;
        var listdata = this.data.listdata;
        var event = event.target.dataset;
        for (var i in listdata) {
            if (listdata[i].key == event.key) {
                for (var j in listdata[i].list) {
                    if (listdata[i].list[j].key == event.val) {
                        listdata[i].list[j].open = !listdata[i].list[j].open;
                    }
                }
            }
        }
        getpt(event);
        that.setData({
            listdata: listdata
        });
        // 打开标题栏加载动画
        wx.showNavigationBarLoading();
        that.getsx();
    },
    onShareAppMessage: function () {
        return {
        title: '网贷平台筛选',
        desc: '',
        path: '/pages/index/siftlist'
        }
    }
})
