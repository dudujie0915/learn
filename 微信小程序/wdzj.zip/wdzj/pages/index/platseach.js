//platseach.js
//获取应用实例
var app = getApp();
var platLists = [];
Page({
    data: {
        inputShowed: false,
        inputVal: "",
        platList: []
    },
    showInput: function() {
        this.setData({
            inputShowed: true
        });
    },
    hideInput: function() {
        this.setData({
            inputVal: "",
            inputShowed: false
        });
    },
    clearInput: function() {
        this.setData({
            inputVal: ""
        });
    },
    inputTyping: function(e) {
        var that = this;
        var v = e.detail.value;
        var arr = [];
        for (var i = 0; i < platLists.length; i++) {
            if (platLists[i].allPlatNamePin.indexOf(v) >= 0 || platLists[i].platNamePin.indexOf(v) >= 0 || platLists[i].platName.indexOf(v) >= 0) {
                arr.push(platLists[i]);
            }
        }
        var arr1 = [];
        for (var j = 0; j < arr.length; j++) {
            if(j<30){
                arr1.push(arr[j]);
            }else{
                j = arr.length;
            }
        }
        // 更新数据
        this.setData({
            inputVal: v,
            platList: arr1
        });
    },
    onLoad: function() {
        var that = this;

        app.localData("index-platseach",''
            ,function(set) {
                // 打开标题栏加载动画
                wx.showNavigationBarLoading();

                //更新数据
                wx.request({
                    url: 'https://phpservice.wdzj.com/wxchat/index/IplatSelect',
                    data: {
                        "sort": "firstPin"
                    },
                    header: {
                        'content-type': 'application/json'
                    },
                    success: function(res) {
                        platLists = res.data.data;

                        // 关闭标题栏加载动画
                        wx.hideNavigationBarLoading();
                        set(platLists);
                    },
                    fail: function() {
                        app.failShow()
                    }
                })
            }
            ,function(data) {
                platLists = data;
            }
        );
    },
    onShareAppMessage: function () {
        return {
        title: 'P2P网贷平台搜索',
        desc: '网贷平台搜索方便用户对网贷平台资料信息的检索',
        path: '/pages/index/platseach'
        }
    }
});
