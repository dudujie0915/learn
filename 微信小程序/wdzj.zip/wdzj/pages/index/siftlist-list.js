//siftlist-list.js
var datas = {
    "sort": "",
    "page": 1,
    "pagesize": "20",
    "filedall": "1",
    "params": ""
};
Page({
    data: {
        title:[
            {
                "is":true,
                "name":"默认排序",
                "sort":""
            },{
                "is":false,
                "name":"利率优先",
                "sort":"rate"
            }
        ],
        platList: []
    },
    onLoad: function(options) {
        datas.params = "";
        for (var i in options) {
            datas.params += i + ":" + options[i] + ",";
        }
        this.getlist();
    },
    gettap: function(event) {
        var list = this.data.title;
        var event = event.target.dataset;
        var title = [];
        for(var i=0;i<list.length;i++){
            if(event.val == list[i].name){
                list[i].is = true;
            }else{
                list[i].is = false;
            }
        }
        datas.sort = event.sort;
        this.setData({
            title: list
        });
        this.getlist();
    },
    // 获取平台列表
    getlist:function(event) {
        var that = this;
        // 打开标题栏加载动画
        wx.showNavigationBarLoading();

        // 筛选平台
        wx.request({
            url: 'https://phpservice.wdzj.com/wxchat/index/IplatSelect',
            data: datas,
            header: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            method: "POST",
            success: function(res) {
                var list = that.data.platList;
                for(var i=0;i<res.data.data.length;i++){
                    list.push(res.data.data[i]);
                }
                that.setData({
                    platList: list
                });
                // 关闭标题栏加载动画
                wx.hideNavigationBarLoading();
            },
            fail: function() {
               app.failShow()
            }
        })
    },
    onReachBottom: function() {
        datas.page += 1;
        this.getlist();
    },
    navback: function() {
        wx.navigateBack();
    },
    onShareAppMessage: function () {
        return {
        title: '网贷平台筛选结果',
        desc: '',
        path: '/pages/index/siftlist-list'
        }
    }
})
