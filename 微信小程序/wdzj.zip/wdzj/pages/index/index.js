//index.js
//获取应用实例
var app = getApp();

Page({
    data: {
        date: '1',
        titles: [],
        plats: []
    },
    onLoad: function() {
        var that = this;

        app.localData("indexListData", '', function(set) {
            //更新数据
            wx.request({
                url: 'https://phpservice.wdzj.com/wxchat/index/IpingjiIndex',
                header: {
                    'content-type': 'application/json'
                },
                success: function(res) {
                    var data = res.data.data;
                    that.setData({
                        date: data.date.toString().substr(4,7),
                        titles: data.title,
                        plats: data.list
                    })
                    set(data);
                },
                fail: function() {
                    app.failShow()
                }
            })
        }, function(data) {
            that.setData({
                date: data.date.toString().substr(4,7),
                titles: data.title,
                plats: data.list
            })
        });
    },
     onShareAppMessage: function () {
        return {
        title: '网贷平台档案',
        desc: '网贷平台档案是网贷之家汇集的网贷平台资料信息，包含网贷平台的检索、介绍',
        path: '/pages/index/index'
        }
    }    
});
