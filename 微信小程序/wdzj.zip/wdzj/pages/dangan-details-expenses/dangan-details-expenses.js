// pages/dangan-details-expenses/dangan-details-expenses.js
var platId = '';
var convertHtmlToText = require('../../utils/convertHtmlToText.js');
var app = getApp();
Page({
  data:{
    withdrawExpense:'',
    manageExpense:'',
    vipExpense:'',
    rechargeExpense:'',
    transferExpense:'',
    paymode:'',
    hidden:false
  },
  onLoad:function(options){
    var that = this;
    platId = options.platId;
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IarchiveFee',
      data: {
        platId:options.platId
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        var json = res.data.data;
        that.setData({
          withdrawExpense:convertHtmlToText.convertHtmlToText(json.platfee.withdrawExpense),
          manageExpense:convertHtmlToText.convertHtmlToText(json.platfee.manageExpense),
          vipExpense:convertHtmlToText.convertHtmlToText(json.platfee.vipExpense),
          rechargeExpense:convertHtmlToText.convertHtmlToText(json.platfee.rechargeExpense),
          transferExpense:convertHtmlToText.convertHtmlToText(json.platfee.transferExpense),
          paymode:convertHtmlToText.convertHtmlToText(json.paymode),
          hidden:true
        });
      },
      fail: function() {
          app.failShow()
      }
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onShareAppMessage: function () {
        return {
        title: '平台费用',
        desc: '',
        path: '/pages/dangan-details-expenses/dangan-details-expenses?platId='+platId
        }
    }
})