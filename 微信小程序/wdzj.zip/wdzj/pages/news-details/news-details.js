// pages/news-details/news-details.js
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
var tid = '';
Page({
  data:{
    hidden : false,
    contentShow : true,
    headShow : true,
    title : "",
    source : "",
    details_time : "",
    pageView : "",
    PageNum : 1,
    appkey : '',
    appid : 0,
    type : 0,
    id : 0,
    height : 'auto',
    comment : [],
    message : []
  },
  onLoad:function(options){
    var that = this;
    var article = '';
    tid = options.tid;
    // 初始化内容
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/InewsDetail',
      data: {
        newsId : options.tid
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {        
        var json = res.data; 
        if(json.error_code == 0){
          article = json.data.news.content;
          WxParse.wxParse('article', 'html', article, that);
          that.setData({
            hidden : true,
            title : json.data.news.title,
            source : json.data.news.resourceFrom,
            details_time : json.data.news.publishDate,
            pageView : json.data.news.hits,
            headShow : false,
            appkey : json.data.appkey,
            appid : json.data.appid,
            type : json.data.type,
            id : json.data.id
          });
        }

        // 初始化评论
        that.initComment(that.data.PageNum);
      },
      fail:function(){
        app.failShow()
      } 
    });

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          height : res.windowHeight + "px"
        });
      }
    });

    
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },

  initComment : function(pageNum){
    var that = this;
    var data = {
          appid : that.data.appid,
          appkey : that.data.appkey,
          type : that.data.type,
          page : pageNum,
          id : that.data.id
        };

    that.listData(data,function(res){
          that.setData({
            hidden : false,
          });
          
          if(res.data.length > 0){
            that.setData({
              comment : that.data.comment.concat(res.data),
              contentShow : false
            });
          }

          for(let i=0; i<res.data.length; i++){
            that.data.message.push(res.data[i].content);
            WxParse.wxParse('reply' + i, 'html', that.data.message[i], that);

            if (i === res.data.length - 1) {
              WxParse.wxParseTemArray("replyTemArray",'reply', res.data.length, that);
            }
          }

          that.setData({
            hidden : true
          });
      });
    },
  

  listData : function(data,callback){
    var that = this;
    wx.request({
      url: 'https://phpservice.wdzj.com/comment/getHotComment',
      data: data,
      method: 'GET',
      header: {
        'content-type': 'application/json'
      }, 
      success: function(res){
        callback(res);
      },
      fail:function(){
        app.failShow()
      }
    })
  },
  onShareAppMessage: function () {
      var that = this;
      return {
      title: that.data.title,
      desc: '',
      path: '/pages/news-details/news-details?tid='+tid
      }
  }
})

  