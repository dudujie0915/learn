// pages/dangan-details-executives/dangan-details-executives.js
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
var platId = '';
Page({
  data:{
    list:[],
    hidden:false
  },
  onLoad:function(options){
    var that = this;
    var message = [];
    platId = options.platId;
    // 页面初始化 options为页面跳转所带来的参数
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IarchiveprincipalInfo', //仅为示例，并非真实的接口地址
      data: {
        platId:options.platId
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        var json = res.data;
        that.setData({
          list:json.data,
          hidden:true
        });

        for(let i=0; i<json.data.length; i++){
            message.push(json.data[i].principalDetail);
            WxParse.wxParse('reply' + i, 'html', message[i], that);
            if (i === json.data.length - 1) {
              WxParse.wxParseTemArray("replyTemArray",'reply', json.data.length, that);
            }
        }
      },
      fail: function() {
          app.failShow()
      }
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onShareAppMessage: function () {
        return {
        title: '平台高管',
        desc: '',
        path: '/pages/dangan-details-executives/dangan-details-executives?platId='+platId
        }
    }
})