// pages/dangan-details-contact/dangan-details-contact.js
var platId = '';
var app = getApp();
Page({
  data:{
    officeAddress:'',
    serviceTel:'',
    servicePhone:'',
    serviceFax:'',
    qqGroup1:'',
    serviceMailAddress:'',
    serviceQq1:'',
    hidden:false
  },
  onLoad:function(options){
    var that = this;
    platId = options.platId;
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IarchiveWebsiteInfo', //仅为示例，并非真实的接口地址
      data: {
        platId:options.platId
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        var json = res.data.data;
        that.setData({
          officeAddress:json.platInfo.officeAddress,
          serviceTel:json.platInfo.serviceTel,
          servicePhone:json.platInfo.servicePhone,
          serviceFax:json.platInfo.serviceFax,
          qqGroup1:json.platInfo.qqGroup1,
          serviceMailAddress:json.platInfo.serviceMailAddress,
          serviceQq1:json.platInfo.serviceQq1,
          hidden:true
        });
      },
      fail: function() {
          app.failShow()
      }
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  phone:function(event){
    wx.makePhoneCall({
      phoneNumber: event.target.dataset.tel
    })
  },
  onShareAppMessage: function () {
        return {
        title: '联系平台',
        desc: '',
        path: '/pages/dangan-details-contact/dangan-details-contact?platId='+platId
        }
    }
})