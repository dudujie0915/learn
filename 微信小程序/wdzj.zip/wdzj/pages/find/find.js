// pages/find/find.js
Page({
  data:{
    dataArr : [
       {"name":"JSON.HUO","time":"2016-10-10","title":"这篇文章主要介绍了微信小程序 location API接口相关资料"},
       {"name":"maker","time":"2016-10-11","title":"最终发送给服务器的数据是 String 类型"}
    ]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onShareAppMessage: function () {
    var that = this;
        return {
        title: '发现',
        desc: '发现更多关于网贷之家的精彩内容',
        path: '/pages/find/find'
        }
    }
})