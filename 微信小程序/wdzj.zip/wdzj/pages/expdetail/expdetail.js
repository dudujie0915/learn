// pages/expdetail/expdetail.js
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
var tid = '';
Page({
  data:{
      "title":"",
      "source":"",
      "details_time":"",
      "pageView":'',
      "username":"",
      "headerId" : "",
      "condition" : false,
      "platName" : "",
      "platLink" : "",
      "platque" : "",
      "hidden" : false,
      "imageHidden" : true,
      "comment":[]
  },
  onLoad:function(options){
    var that = this;
    var article = '';
    var message = [];
    tid = options.tid;
    // 页面初始化 options为页面跳转所带来的参数

    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IthreadExposureDetail', 
      data: {
        tid: options.tid
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        that.setData({
          hidden : true
        });
        var json = res.data;
        if(json.error_code == 0){
          article = json.data.thread.message;
          WxParse.wxParse('article', 'html', article, that);
          
          that.setData({
            title : json.data.thread.subject,
            headerId : json.data.thread.author_id,
            username : json.data.thread.nickname,
            details_time : json.data.thread.hommization_time,
            condition : json.data.typeoption.length > 0 ? true : false,
            platName : json.data.typeoption[0] ? json.data.typeoption[0].value : "",
            platLink : json.data.typeoption[1] ? json.data.typeoption[1].value : "",
            platque : json.data.typeoption[2] ? json.data.typeoption[2].value : "",
            imageHidden : false,
            comment : json.data.commentNew
          });
          
          for(let i=0; i<json.data.commentNew.length; i++){
            message.push(json.data.commentNew[i].message);
            WxParse.wxParse('reply' + i, 'html', message[i], that);

            if (i === json.data.commentNew.length - 1) {
              WxParse.wxParseTemArray("replyTemArray",'reply', json.data.commentNew.length, that)
            }
          }

        }
      },
      fail:function(){
        app.failShow()
      }
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onShareAppMessage: function () {
      return {
      title: '曝光详情',
      desc: '',
      path: '/pages/expdetail/expdetail?tid='+tid
      }
  }
})

  