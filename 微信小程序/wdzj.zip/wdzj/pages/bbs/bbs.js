// pages/bbs/bbs.js
var app = getApp();
Page({
  data:{
    hidden : false,
    pageNum : 2,
    nodata: true,
    text : [],
    height : 'auto',
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this;

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          height : res.windowHeight + "px"
        });
      }
    });

    that.dataRequest(1,function(res){
      var json = res.data;
      if(json.error_code == 0){
        that.setData({
          text : json.data.postlist.data,
          hidden : true
        });
      }
    });   
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onReachBottom:function(){
    var that = this;
    that.refesh();
  },

  refesh : function(){
    var that = this;
    that.setData({
        hidden : false
    });
 
    that.dataRequest(that.data.pageNum,function(res){
      var json = res.data;
      if(json.error_code == 0){
        if(json.data.postlist.error_code == -1){
          that.viewsData();
        } else {

          that.setData({
            pageNum : that.data.pageNum+1,
            text : that.data.text.concat(json.data.postlist.data),
            hidden : true
          });
        }
      }
    });
  },

  dataRequest : function(pageNum,callback){
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IthreadExposure',
      data: {
        page : pageNum,
      },
      method: 'GET', 
      header: {
        'content-type': 'application/json'
      },
      success: function(res){
        callback(res);
      },
      fail:function(){
        app.failShow()
      }
    });
  },

  viewsData : function(){
    var that = this;
    that.setData({
      nodata : false,
      hidden : true
    });

    setTimeout(function(){
      that.setData({
        nodata : true
      });
    },2000);
  },
  onShareAppMessage: function () {
    var that = this;
        return {
        title: '平台曝光',
        desc: '',
        path: '/pages/bbs/bbs'
        }
    }
});