// pages/dangan-details-info/dangan-details-info.js
var WxParse = require('../../wxParse/wxParse.js');
var platId = '';
var app = getApp();
Page({
  data:{
    hidden:false
  },
  onLoad:function(options){
    var article = '';
    var that = this;
    platId = options.platId;
    // 页面初始化 options为页面跳转所带来的参数
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/Iarchivebaseinfo', //仅为示例，并非真实的接口地址
      data: {
        platId:options.platId
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        console.log(res);
        article = res.data.data;
        WxParse.wxParse('article','html',article, that);
        that.setData({
          hidden:true
        })
      },
      fail: function() {
          app.failShow()
      }
    });
   
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onShareAppMessage: function () {
        return {
        title: '平台简介',
        desc: '',
        path: '/pages/dangan-details-info/dangan-details-info?platId='+platId
        }
    }
})

  