// pages/dangan-details/dangan-details.js
var platId = '';
var app = getApp();
Page({
  data:{
    hidden:true,
    platId:'',//id
    platName:'',//陆金所
    userNav:'',//关注人数
    platStatus:'',//关注人数状态
    platStatuFormat:'',
    platBackgroundDetail:'',//银行系
    diffMonth:'',//11月
    zonghezhishu:'',//发展指数
    zonghezhishuRank:'',//发展指数排名

    incomeRate:'',//平均利率
    loanPeriod:'',//平均期限
    amount:'',//昨日成交量
    amountNew:'',
    netFlow:'',//昨日资金净流入
    netFlowNew:'',
    stayStill:'',//历史待还
    stayStillNew:'',
    avgBorMoney:'',//人均借款金额
    avgBorMoneyNew:'',
    topBorProportion:'',//十大借款人占比
    fullTime:'',//满标用时
    reviewScore:'',//投友评分
    reviewCount:'',//*位投友评分

    riskcontrolDetail:'',//融资
    fundCapital:'',//资金存托管
    associationDetail:'',//监管协会
    gjlhhFlag:'',//国金联合会
    gjlhhTime:'',//国金联合会加入时间
    equity:'',//上市

    autoBid:'',//自动投标
    bidSecurity:'',//投资保障
    securityModel:'',//保障模式
    gruarantee:'',//担保机构
    newTrustCreditor:'',//债权转让

    sumary:'',//平台简介
    princ:'',//高管简介
    certificate:'',//工商备案
    fee:'',//平台费用
    picture:'',//现场实拍
    contract:'',//联系平台

    maxElements:'',//投友点评总数
    scores_d:[],
    scores_v:[],
    tagList:[],
    list:[]

  },
  onLoad:function(options){
    var that = this;
    platId = options.platid;
    //更新数据--基础
    wx.request({
        url: 'https://phpservice.wdzj.com/wxchat/index/IdanganDetail',
        data:{
          platId:options.platid
        },
        header: {
            'content-type': 'application/json'
        },
        success: function(res) {
            that.setData({
                platId:res.data.data.baseinfo.platBase.platId,
                platName:res.data.data.baseinfo.platBase.platName,
                userNav:res.data.data.baseinfo.platBase.userNav,
                platStatus:res.data.data.baseinfo.platBase.platStatus,
                platStatuFormat:res.data.data.baseinfo.platBase.platStatuFormat,
                platBackgroundDetail:res.data.data.baseinfo.platBase.platBackgroundDetail,
                diffMonth:res.data.data.baseinfo.platBase.diffMonth,
                zonghezhishu:res.data.data.baseinfo.platBase.zonghezhishu,
                zonghezhishuRank:res.data.data.baseinfo.platBase.zonghezhishuRank,

                incomeRate:res.data.data.baseinfo.platShuju.incomeRate,
                loanPeriod:res.data.data.baseinfo.platShuju.loanPeriod,
                amount:that.conversion(res.data.data.baseinfo.platShuju.amount),
                amountNew:that.conversionNew(res.data.data.baseinfo.platShuju.amount),
                netFlow:that.conversion(res.data.data.baseinfo.platShuju.netFlow),
                netFlowNew:that.conversionNew(res.data.data.baseinfo.platShuju.netFlow),
                stayStill:that.conversion(res.data.data.baseinfo.platShuju.stayStill),
                stayStillNew:that.conversionNew(res.data.data.baseinfo.platShuju.stayStill),
                avgBorMoney:that.conversion(res.data.data.baseinfo.platShuju.avgBorMoney),
                avgBorMoneyNew:that.conversionNew(res.data.data.baseinfo.platShuju.avgBorMoney),
                topBorProportion:res.data.data.baseinfo.platShuju.topBorProportion,
                fullTime:res.data.data.baseinfo.platShuju.fullTime,
                reviewScore:res.data.data.baseinfo.platShuju.reviewScore,
                reviewCount:res.data.data.baseinfo.platShuju.reviewCount,

                riskcontrolDetail:that.formatStr(res.data.data.baseinfo.platLevel.riskcontrolDetail),
                fundCapital:that.formatStr(res.data.data.baseinfo.platLevel.fundCapital),
                associationDetail:that.formatStr(res.data.data.baseinfo.platLevel.associationDetail),
                gjlhhFlag:res.data.data.baseinfo.platLevel.gjlhhFlag,
                gjlhhTime:res.data.data.baseinfo.platLevel.gjlhhTime,
                equity:that.formatStr(res.data.data.baseinfo.platLevel.equity),

                newTrustCreditor:res.data.data.baseinfo.platService.newTrustCreditor,
                autoBid:res.data.data.baseinfo.platService.autoBid,
                bidSecurity:that.formatStr(res.data.data.baseinfo.platService.bidSecurity),
                securityModel:that.formatStr(res.data.data.baseinfo.platService.securityModel),
                gruarantee:that.formatStr(res.data.data.baseinfo.platService.gruarantee),

                sumary:res.data.data.baseinfo.existInfo.sumary,
                princ:res.data.data.baseinfo.existInfo.princ,
                certificate:res.data.data.baseinfo.existInfo.certificate,
                fee:res.data.data.baseinfo.existInfo.fee,
                picture:res.data.data.baseinfo.existInfo.picture,
                contract:res.data.data.baseinfo.existInfo.contract,

                hidden:false

            });
        },
        fail:function(){
          app.failShow()
        }
    });
    
  },
  onReady:function(){
    // 页面渲染完成
    var that = this;
    //更新数据--投友点评
    wx.request({
        url: 'https://phpservice.wdzj.com/wxchat/index/IComment',
        data:{
          platId:platId,
          page:1,
          pagesize:1
        },
        header: {
            'content-type': 'application/json'
        },
        success: function(res) {
          var json = res.data.data;
          that.setData({
            maxElements:json.list.maxElements,
            scores_d:json.header.scores_d,
            scores_v:json.header.scores_v,
            tagList:json.header.tagList,
            list:json.list.list
          });
        },
        fail:function(){
          app.failShow()
        }
    });
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onReachBottom:function(){
    
  },
  formatStr:function(str){
    str = str.replace(/&nbsp;/g, " ");
    str = str.replace(/<br>/g, "\n");
    str = str.replace(/<br\/>/g, "\n");
    return str;
  },
  conversion:function(num){
    var value = num/10000;
    if(value >= 1 || value <= -1){
      num = value.toFixed(2);
    } else {
      num = value.toFixed(6);
    }
    return num;
  },
  conversionNew:function(num){
    var value = num/10000;
    if(value >= 1 || value <= -1){
      num = value.toFixed(2);
    } else {
      num = (value*10000).toFixed(2);
    }
    return num;
  },
  onShareAppMessage: function () {
    var that = this;
        return {
        title: that.data.platName+'网贷档案',
        desc: that.data.platName+'网贷平台档案是由网贷之家为您精心收集整理的有关的信息和数据',
        path: '/pages/dangan-details/dangan-details?platid='+platId
        }
    }
})