// pages/dangan-details-comment/dangan-details-comment.js
//var WxParse = require('../../wxParse/wxParse.js');
var platId = '';
var allcomment = '';
var app = getApp();
Page({
  data:{
    maxElements:'',//投友点评总数
    scores_d:[],
    scores_v:[],
    tagList:[],
    list:[],
    message:[],
    height : 'auto',
    pageNum:1,
    loading : false
  },
  onLoad:function(options){
     var that = this;
     platId = options.platId;
     var headUrl = 'https://phpservice.wdzj.com/wxchat/index/IComment';

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          height : res.windowHeight + "px"
        });
      }
    });

    // 初始化
    that.listData(that.data.pageNum,function(res){
      var json = res.data;
      if(json.error_code == 0){
        that.setData({
          pageNum : that.data.pageNum + 1,
          loading : true,
          maxElements:json.data.list.maxElements,
          scores_d:json.data.header.scores_d,
          scores_v:json.data.header.scores_v,
          tagList:json.data.header.tagList,
          list:json.data.list.list
        });
        allcomment =  Math.ceil(that.data.maxElements/10);
        /*
        for(let i=0; i<json.data.list.list.length; i++){
            that.data.message.push(json.data.list.list[i].reviewContent);
            console.log(that.data.message);
            WxParse.wxParse('reply' + i, 'html', that.data.message[i], that);

            if (i === json.data.list.list.length - 1) {
              WxParse.wxParseTemArray("replyTemArray",'reply',json.data.list.list.length, that);
              console.log(that.data.comment);
            }
          }
         */ 
      }
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onReachBottom:function(){
    var that = this;
    that.refesh();
  },
  refesh : function(){
    var that = this;
    if(that.data.pageNum <= allcomment){
        that.setData({
          loading : false,
        });
    }

    that.listData(that.data.pageNum,function(res){
      var json = res.data;
      if(json.error_code == 0){
        if(json.data.list.list.length > 0){
            that.setData({
              pageNum : that.data.pageNum + 1,
              loading : true,
              list:that.data.list.concat(json.data.list.list)
            });
            /*
            for(let i=0; i<json.data.list.list.length; i++){
            that.data.message.push(json.data.list.list[i].reviewContent);
            WxParse.wxParse('reply' + i, 'html', that.data.message[i], that);

            if (i === json.data.list.list.length - 1) {
              WxParse.wxParseTemArray("replyTemArray",'reply',json.data.list.list.length, that);
              console.log(that.data.comment);
            }
          }
          */

        } else {
          that.setData({
            loading : true,
            nodata : false
          });

          setTimeout(function(){
            that.setData({
              nodata : true
            });
          },2000);
        }
      }
    });
  },
  listData : function(pageNum,callback){
    var that = this;
    wx.request({
      url: 'https://phpservice.wdzj.com/wxchat/index/IComment',
      data: {
        platId:platId,
        page : that.data.pageNum,
        pagesize:10
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function(res){
        callback(res);
      },
      fail: function() {
          app.failShow()
      }
    })
  },
  onShareAppMessage: function () {
        return {
        title: '投友点评',
        desc: '',
        path: '/pages/dangan-details-comment/dangan-details-comment?platId='+platId
        }
    }
})