// 阿拉丁统计
var aldstat = require("./utils/ald-stat.js");

//app.js
App({
  onLaunch: function() {
      // Do something when Launch.
  },
  onShow: function() {
      // Do something when show.
  },
  onHide: function() {
      // Do something when hide.
  },
  onError: function(msg) {
    //console.log(msg)
  },
  // 本地存储数据（默认24小时）
  localData: function(key,time,callback1,callback2) {
    var set = function(data){
        wx.setStorageSync(key,{"time":time,"data":data});
    };
    var list = wx.getStorageSync(key);
    var time = time || (Date.now()+(1000*360*24));
    if(list && list.time > Date.now()){
        callback2(list.data);
    }else{
        callback1(set);
    }
  },
  failShow:function(){
      wx.showModal({
        title: '提示',
        content: '数据异常，请稍后再试！或联系客服',
        showCancel: false
     });
  }
})