exports.app_key = "d3a37947af5362d966bd6212e21aba73";
exports.getLocation = true;
