//demo.js
//获取应用实例
var app = getApp()
Page({
  data: {
      texts: {ts:'aa2'},
    text: 'init data',
    array: [{text: 'init data1'}],
    object: {
      text: 'init data2'
    },
     array1: [1, 2, 3, 4, 5],
      view: 'MINA',
      staffA: {firstName: 'Hulk', lastName: 'Hu'},
    staffB: {firstName: 'Shang', lastName: 'You'},
    staffC: {firstName: 'Gideon', lastName: 'Lin'},
     name: 'MINA',
     flag:false,
     zero: 0,
     a: 1,
    b: 2,
    item1: {
      index: 0,
      msg: 'this is a template',
      time: '2016-09-15'
    },
    arrays: ['美国', '中国', '巴西', '日本'],
    indexs: 0,
    date: '2016-09',
    time: '12:01',
    arrayi: [{
      mode: 'scaleToFill',
      text: 'scaleToFill：不保持纵横比缩放图片，使图片完全适应'
    }, { 
      mode: 'aspectFit',
      text: 'aspectFit：保持纵横比缩放图片，使图片的长边能完全显示出来'
    }, { 
      mode: 'aspectFill',
      text: 'aspectFill：保持纵横比缩放图片，只保证图片的短边能完全显示出来'
    }, { 
      mode: 'top',
      text: 'top：不缩放图片，只显示图片的顶部区域' 
    }, {      
      mode: 'bottom',
      text: 'bottom：不缩放图片，只显示图片的底部区域'
    }, { 
      mode: 'center',
      text: 'center：不缩放图片，只显示图片的中间区域'
    }, { 
      mode: 'left',
      text: 'left：不缩放图片，只显示图片的左边区域'
    }, { 
      mode: 'right',
      text: 'right：不缩放图片，只显示图片的右边边区域'
    }, { 
      mode: 'top left',
      text: 'top left：不缩放图片，只显示图片的左上边区域' 
    }, { 
      mode: 'top right',
      text: 'top right：不缩放图片，只显示图片的右上边区域'
    }, { 
      mode: 'bottom left',
      text: 'bottom left：不缩放图片，只显示图片的左下边区域'
    }, { 
      mode: 'bottom right',
      text: 'bottom right：不缩放图片，只显示图片的右下边区域'
    }],
    src: 'https://mp.weixin.qq.com/debug/wxadoc/dev/image/cat/0.jpg?t=20161122'
  },
  imageError: function(e) {
    console.log('image3发生error事件，携带值为', e.detail.errMsg)
  },
   changeText: function() {
    // this.data.text = 'changed data'  // bad, it can not work
    this.setData({
      text: 'changed data'
    })
  },
  changeItemInArray: function() {
    // you can use this way to modify a danamic data path
    this.setData({
      'array[0].text':'changed data1'
    })
  },
  changeItemInObject: function(){
    this.setData({
      'object.text': 'changed data2'
    });
  },
  addNewField: function() {
    this.setData({
      'newField.text': 'new data'
    })
  },
  tapName: function(event) {
    console.log(event)
  },
  onShow:function(){
      console.log(11);
  },
  tapclick:function(){
      this.setData({
          'texts.ts' : 'tap click'
      })
  },
  bindPickerChange: function(e) {
  console.log('picker发送选择改变，携带值为', e.detail.value)
  this.setData({
    indexs: e.detail.value
  })
  },
  bindDateChange: function(e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function(e) {
    this.setData({
      time: e.detail.value
    })
  }
})
