export function sum(...x) {
    return x.reduce((m, n) => m + n);
}

export var pi = 3.141593;