// 模块
import * as app from "f10_modules_app";

function f10_modules() {

    console.log("\nf10:Modules");

    app.execute(); // 输出：π = 3.141593 2π = 6.283186 3π = 9.424779 4π = 12.566372
}

module.exports = f10_modules;