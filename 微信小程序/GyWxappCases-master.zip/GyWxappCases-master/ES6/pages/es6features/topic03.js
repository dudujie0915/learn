//

function topic03() {

    console.log("\ntopic03...");

}

module.exports = topic03