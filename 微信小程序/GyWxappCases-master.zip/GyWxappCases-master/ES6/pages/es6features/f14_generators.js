// 生成器

function f14_generators() {

    console.log("\nf14:Generators");

    /*
    function* helloWorldGenerator() {
        yield 'hello';
        yield 'world';
        return 'ending';
    }

    var hw = helloWorldGenerator();

    console.log(hw.next());
    */
}

module.exports = f14_generators;