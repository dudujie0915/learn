// Symbol

function f12_symbol_type() {

    console.log("\nf12:Symbol Type");

    let s = Symbol();
    console.log(typeof s); // 输出: symbol
}

module.exports = f12_symbol_type;